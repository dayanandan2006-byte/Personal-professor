# 🌉 Skill Bridge AI
**Personalized Mentorship & Skill Analytics Engine** - Team Low Keys

An AI mentor for students in Tier-2 and Tier-3 cities. It tells a student *what to learn, why, and how* across three tracks:

| Track | What it does |
|---|---|
| 🎓 Education | Parses the student's skills, finds the gap to a chosen career, and builds an ordered roadmap (skills → projects → certificate → internship → career) |
| 🏏 Sports | Builds a weekly cricket training plan by role and level, and tracks sessions over time |
| 🚀 Business | Scores a business idea and walks the founder through Idea → Validation → MVP → Feedback → Improvement → Growth |

It also fights drop-out with a daily check-in streak and motivational nudges.

## Run it
```bash
pip install -r requirements.txt
streamlit run app.py
```
It works **fully offline** with the built-in rule-based engine. To turn on the free-form Claude mentor:
```bash
export ANTHROPIC_API_KEY="your-key"      # Windows PowerShell: $env:ANTHROPIC_API_KEY="your-key"
streamlit run app.py
```
Optional: `SKILLBRIDGE_MODEL` overrides the model name.

## Files
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI (5 tabs + sidebar check-in) |
| `engine.py` | All logic: skill parsing, gap analysis, roadmap, training plans, idea scoring, streaks |
| `skill_data.py` | Skills, prerequisites, careers, drills, business stages. **Extend the platform by editing this file** |
| `llm.py` | Optional Claude mentor wrapper |
| `storage.py` | Saves each student's progress to `data/<name>.json` |

## 2-minute demo flow
1. Enter a name → **Education**: type `Python, SQL`, pick *Data Scientist* → show the gap and roadmap (matches the example on your Opportunity slide).
2. Tick a few steps, press **Check in today** → streak goes up.
3. **Sports**: pick *Fast Bowler*, 4 days → show the plan, log a session, show the trend chart.
4. **Business**: describe an idea, move the scorecard sliders → readiness score and stage checklist.
5. **Mentor**: ask "what should I do next?" (and, with an API key, something open-ended).

## Be honest with judges
- Time estimates are rough heuristics (about 10 study hours/week per skill, scaled linearly), not measured results. Don't claim cost-saving percentages unless you have data - your own slide 6 notes say the same.
- Course and certificate names are suggestions; verify current availability and fees.
- Sports plans are general guidance, not medical or coaching advice.
- The skill graph covers 20 skills and 6 careers - a starting point, not an industry-complete dataset.

## Ideas to extend (if you have time)
- Add a skills/careers CSV from NASSCOM-style reports and load it in `skill_data.py`
- Add regional-language support in `llm.py` (ask the mentor to reply in Tamil, Hindi, etc.)
- Add a quiz per skill to measure real progress instead of self-reported skills
