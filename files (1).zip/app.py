"""Skill Bridge AI - Personalized Mentorship & Skill Analytics Engine.

Run with:  streamlit run app.py
"""
import json
from datetime import date, timedelta

import pandas as pd
import streamlit as st

import engine
import llm
import storage
from skill_data import CAREERS, LEVELS, ROLES, SCORE_CRITERIA, STAGES

st.set_page_config(page_title="Skill Bridge AI", page_icon="🌉", layout="wide")


def ai_call(context: str, messages: list[dict]) -> str | None:
    """Return the AI reply, or None (after showing a friendly error) if it fails."""
    try:
        return llm.ask(context, messages)
    except Exception as exc:  # network, bad key, rate limit...
        st.error(f"The AI mentor is unavailable right now ({type(exc).__name__}). "
                 "The rule-based mentor still works.")
        return None


# ----------------------------------------------------------------- sidebar ---
st.sidebar.title("🌉 Skill Bridge AI")
st.sidebar.caption("Your personal AI mentor: what to learn, why, and how.")
name = st.sidebar.text_input("Your name", value=st.session_state.get("name", ""),
                             placeholder="Type your name and press Enter")
st.session_state["name"] = name

if not name.strip():
    st.title("🌉 Skill Bridge AI")
    st.subheader("Personalized Mentorship & Skill Analytics Engine")
    st.info("👈 Enter your name in the sidebar to create or reopen your profile.")
    st.markdown(
        "**Three tracks, one mentor:**  \n"
        "🎓 **Education** - skill-gap analysis and a personal roadmap  \n"
        "🏏 **Sports** - training plans and performance tracking  \n"
        "🚀 **Business** - from idea to growth, step by step"
    )
    st.stop()

if st.session_state.get("loaded_for") != name:
    st.session_state["profile"] = storage.load_profile(name)
    st.session_state["loaded_for"] = name
    st.session_state["chat"] = []
profile = st.session_state["profile"]
snapshot = json.dumps(profile, sort_keys=True)
uid = storage.slug(name)


def K(label: str) -> str:
    """Widget keys are namespaced per student so profiles never leak into each other."""
    return f"{uid}:{label}"


# daily check-in (retention)
today = date.today()
if st.sidebar.button("✅ Check in today", use_container_width=True):
    if today.isoformat() not in profile["checkins"]:
        profile["checkins"].append(today.isoformat())
        st.sidebar.success("Checked in. Nice work!")
    else:
        st.sidebar.info("Already checked in today.")
streak_days = engine.streak(profile["checkins"])
st.sidebar.metric("🔥 Day streak", streak_days)
st.sidebar.caption("AI mentor: " + ("on (Claude)" if llm.available() else "offline mode (rule-based)"))

st.title(f"Welcome, {name}!")
tab_edu, tab_sport, tab_biz, tab_mentor, tab_prog = st.tabs(
    ["🎓 Education", "🏏 Sports", "🚀 Business", "🤖 Mentor", "📈 Progress"]
)

# ---------------------------------------------------------------- education ---
with tab_edu:
    st.subheader("Skill-gap analysis & personal roadmap")
    c1, c2 = st.columns([2, 1])
    profile["skills_text"] = c1.text_area(
        "Skills you already have (comma-separated)", value=profile["skills_text"],
        key=K("skills"), height=110, placeholder="e.g. Python, SQL, HTML",
    )
    careers = list(CAREERS)
    if profile["career"] not in careers:
        profile["career"] = careers[0]
    profile["career"] = c2.selectbox("Career goal", careers, index=careers.index(profile["career"]),
                                     key=K("career"))
    profile["hours"] = c2.slider("Study hours per week", 3, 30, int(profile["hours"]), key=K("hours"))

    have, unknown = engine.parse_skills(profile["skills_text"])
    if have:
        st.success("Skills recognised: " + ", ".join(have))
    if unknown:
        st.caption("Not tracked yet (kept in your profile): " + ", ".join(unknown))

    roadmap = engine.build_roadmap(have, profile["career"], profile["hours"])
    m1, m2, m3 = st.columns(3)
    m1.metric(f"Match with {profile['career']}", f"{roadmap['match_pct']}%")
    m2.metric("Skills still to learn", roadmap["learn_count"])
    m3.metric("Rough time to goal", f"{roadmap['total_weeks']} weeks",
              help="Rough estimate that scales with your weekly study hours. Not a guarantee.")
    st.markdown(f"**Your path:** {roadmap['path_text']}")

    st.markdown("#### Your roadmap")
    done_before = set(profile["done"])
    done_now: set[str] = set()
    for i, step in enumerate(roadmap["steps"], start=1):
        with st.container(border=True):
            label = f"**{i}. {step['title']}**" + (f"  ·  ~{step['weeks']} wk" if step["weeks"] else "")
            if st.checkbox(label, value=step["id"] in done_before, key=K("step:" + step["id"])):
                done_now.add(step["id"])
            st.caption(step["why"])
            if step["resources"]:
                st.markdown("Resources: " + "  ·  ".join(step["resources"]))
            for d in step["details"]:
                st.markdown(f"- {d}")
    current_ids = {s["id"] for s in roadmap["steps"]}
    profile["done"] = sorted(done_now | (done_before - current_ids))
    edu_pct = round(100 * len(done_now) / len(roadmap["steps"]))
    st.progress(edu_pct / 100, text=f"Roadmap progress: {edu_pct}%")
    st.caption("Course and certificate names are suggestions - check current availability and fees.")

    note_key = K("note")
    if st.button("✨ Get my mentor note"):
        ctx = engine.profile_context(profile, roadmap)
        note = None
        if llm.available():
            with st.spinner("Your mentor is thinking..."):
                note = ai_call(ctx, [{"role": "user", "content":
                    "Give me a short, personal plan: what I should learn first, why, and how to start "
                    "this week."}])
        st.session_state[note_key] = note or engine.offline_summary(roadmap)
    if st.session_state.get(note_key):
        st.info(st.session_state[note_key])

# ------------------------------------------------------------------- sports ---
with tab_sport:
    st.subheader("Sports track: cricket training plan")
    sp = profile["sports"]
    s1, s2, s3 = st.columns(3)
    roles = list(ROLES)
    sp["role"] = s1.selectbox("Your role", roles, index=roles.index(sp["role"]) if sp["role"] in roles else 0,
                              key=K("role"))
    levels = list(LEVELS)
    sp["level"] = s2.selectbox("Your level", levels,
                               index=levels.index(sp["level"]) if sp["level"] in levels else 0, key=K("level"))
    sp["days"] = s3.slider("Training days per week", 3, 6, int(sp["days"]), key=K("days"))
    sp["goal"] = st.text_input("Main goal", value=sp["goal"], key=K("goal"),
                               placeholder="e.g. make the district team trials in 3 months")

    plan = engine.build_training_plan(sp["role"], sp["level"], sp["days"], sp["goal"])
    st.markdown("#### Your weekly plan")
    for d in plan["days"]:
        with st.expander(f"{d['day']} - {d['type']} ({d['minutes']} min)", expanded=False):
            for item in d["items"]:
                st.markdown(f"- {item}")
    for n in plan["notes"]:
        st.caption("• " + n)

    st.markdown("#### Log a session")
    with st.form(K("sessionform"), clear_on_submit=True):
        f1, f2, f3 = st.columns(3)
        log_date = f1.date_input("Date", value=today)
        log_type = f2.selectbox("Session type", ["Skill", "Fitness", "Match simulation", "Rest/Recovery"])
        minutes = f3.number_input("Minutes", min_value=0, max_value=240, value=45, step=5)
        g1, g2 = st.columns(2)
        effort = g1.slider("Effort (1 easy - 10 maximum)", 1, 10, 6)
        skill = g2.slider("How well did it go? (1-10)", 1, 10, 6)
        note = st.text_input("Notes (optional)")
        if st.form_submit_button("Save session"):
            sp["logs"].append({"date": log_date.isoformat(), "type": log_type, "minutes": int(minutes),
                               "effort": effort, "skill_rating": skill, "note": note})
            st.success("Session saved.")

    if sp["logs"]:
        df = pd.DataFrame(sp["logs"])
        df["date"] = pd.to_datetime(df["date"])
        daily = df.groupby("date")[["effort", "skill_rating"]].mean()
        st.markdown("#### Performance trend")
        st.line_chart(daily)
        st.dataframe(df.sort_values("date", ascending=False).head(10), use_container_width=True,
                     hide_index=True)
    else:
        st.caption("Log your first session to see your performance trend.")

# ----------------------------------------------------------------- business ---
with tab_biz:
    st.subheader("Business idea track: idea to growth")
    biz = profile["biz"]
    biz["name"] = st.text_input("Idea name", value=biz["name"], key=K("bizname"))
    biz["pitch"] = st.text_area("Describe it in 2-3 sentences: the problem, the customer, your solution",
                                value=biz["pitch"], key=K("bizpitch"), height=100)

    st.markdown("#### Idea scorecard")
    cols = st.columns(3)
    for i, (crit, helptext) in enumerate(SCORE_CRITERIA):
        biz["scores"][crit] = cols[i % 3].slider(crit, 1, 5, int(biz["scores"].get(crit, 3)),
                                                 help=helptext, key=K("score:" + crit))
    result = engine.score_idea(biz["scores"])
    r1, r2 = st.columns([1, 3])
    r1.metric("Idea readiness", f"{result['pct']}%")
    r2.info(result["verdict"] + "  Weakest areas: " + ", ".join(result["weakest"]) + ".")

    st.markdown("#### Your journey: Idea → Validation → MVP → Feedback → Improvement → Growth")
    done_set = set(biz["done"])
    new_done: set[str] = set()
    current_stage = engine.business_progress(biz["done"])["current"]
    for stage in STAGES:
        ids = [engine.stage_item_id(stage["name"], it) for it in stage["checklist"]]
        complete = all(i in done_set for i in ids)
        title = ("✅ " if complete else "🔹 ") + f"{stage['name']} - {stage['goal']}"
        with st.expander(title, expanded=(stage["name"] == current_stage)):
            for item, item_id in zip(stage["checklist"], ids):
                if st.checkbox(item, value=item_id in done_set, key=K("biz:" + item_id)):
                    new_done.add(item_id)
    biz["done"] = sorted(new_done)
    bp = engine.business_progress(biz["done"])
    st.progress(bp["pct"] / 100, text=f"Journey progress: {bp['pct']}% (current stage: {bp['current']})")

    if st.button("💡 Get feedback on my idea"):
        if not biz["name"].strip() and not biz["pitch"].strip():
            st.warning("Add an idea name or description first.")
        elif llm.available():
            with st.spinner("Your mentor is reading your idea..."):
                msg = ("Give honest, constructive feedback on my business idea. Name its biggest risk "
                       f"and one cheap test I can run this week. Idea: {biz['name']}. {biz['pitch']} "
                       f"My scorecard: {biz['scores']}")
                reply = ai_call(engine.profile_context(profile, None), [{"role": "user", "content": msg}])
            if reply:
                st.session_state[K("bizfeedback")] = reply
        else:
            st.session_state[K("bizfeedback")] = (
                result["verdict"] + f" Focus next on: {', '.join(result['weakest'])}. "
                f"Your current stage is '{bp['current']}' - finish its checklist before moving on."
            )
    if st.session_state.get(K("bizfeedback")):
        st.info(st.session_state[K("bizfeedback")])

# ------------------------------------------------------------------- mentor ---
with tab_mentor:
    st.subheader("Ask your AI mentor")
    if not llm.available():
        st.caption("Offline mode: answers come from your roadmap. Set ANTHROPIC_API_KEY for full AI chat.")
    chat = st.session_state["chat"]
    for m in chat:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
    question = st.chat_input("Ask about your skills, training, or business idea...")
    if question:
        chat.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            reply = None
            if llm.available():
                with st.spinner("Thinking..."):
                    reply = ai_call(engine.profile_context(profile, roadmap), chat[-12:])
            if reply is None:
                reply = engine.offline_mentor_reply(question, roadmap)
            st.markdown(reply)
        chat.append({"role": "assistant", "content": reply})

# ----------------------------------------------------------------- progress ---
with tab_prog:
    st.subheader("Your progress")
    week_ago = (today - timedelta(days=6)).isoformat()
    week_sessions = sum(1 for s in sp["logs"] if s["date"] >= week_ago and s["type"] != "Rest/Recovery")
    sports_pct = min(100, round(100 * week_sessions / max(1, sp["days"])))
    st.progress(edu_pct / 100, text=f"🎓 Education roadmap: {edu_pct}%")
    st.progress(sports_pct / 100, text=f"🏏 Training this week: {week_sessions} of {sp['days']} sessions")
    st.progress(bp["pct"] / 100, text=f"🚀 Business journey: {bp['pct']}%")

    last = max((date.fromisoformat(d) for d in profile["checkins"]), default=None)
    gap = (today - last).days if last else None
    st.info(engine.nudge(streak_days, max(edu_pct, bp["pct"]), gap))
    st.caption(f"Total check-ins: {len(profile['checkins'])}")
    st.download_button("⬇️ Download my profile (JSON)", data=json.dumps(profile, indent=2),
                       file_name=f"{uid}-skillbridge.json", mime="application/json")

# ---------------------------------------------------------------------- save ---
if json.dumps(profile, sort_keys=True) != snapshot:
    storage.save_profile(profile)
