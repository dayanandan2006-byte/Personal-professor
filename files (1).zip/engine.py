"""Core logic for Skill Bridge AI. Pure Python - no Streamlit, no network."""
from __future__ import annotations

import difflib
import math
import re
from datetime import date, timedelta

from skill_data import (
    ALIASES, CAREERS, FITNESS_BASE, INTERNSHIP_TIP, LEVELS, MENTAL, ROLES,
    SCORE_CRITERIA, SKILLS, STAGES,
)

# --------------------------------------------------------------------------
# Education track
# --------------------------------------------------------------------------
_CANON = {s.lower(): s for s in SKILLS}


def parse_skills(text: str) -> tuple[list[str], list[str]]:
    """Turn free text like 'py, sql and HTML' into (known skills, unknown words)."""
    known: list[str] = []
    unknown: list[str] = []
    pool = list(_CANON) + list(ALIASES)
    for raw in re.split(r"[,;\n+|]| and ", text or "", flags=re.IGNORECASE):
        token = raw.strip().lower()
        if not token:
            continue
        if token in ALIASES:
            skill = ALIASES[token]
        elif token in _CANON:
            skill = _CANON[token]
        else:
            close = difflib.get_close_matches(token, pool, n=1, cutoff=0.82)
            if close:
                skill = ALIASES.get(close[0]) or _CANON[close[0]]
            else:
                if raw.strip() not in unknown:
                    unknown.append(raw.strip())
                continue
        if skill not in known:
            known.append(skill)
    return known, unknown


def _order_with_prereqs(targets: list[str], have: set[str]) -> list[str]:
    """Skills still to learn, prerequisites first (DFS post-order = topological)."""
    ordered: list[str] = []
    seen: set[str] = set()

    def visit(skill: str) -> None:
        if skill in have or skill in seen:
            return
        seen.add(skill)
        for pre in SKILLS[skill]["prereq"]:
            visit(pre)
        ordered.append(skill)

    for t in targets:
        visit(t)
    return ordered


def build_roadmap(have: list[str], career: str, hours_per_week: int = 10) -> dict:
    """Compare a student's skills to a career and build an ordered roadmap.

    Time estimates are rough heuristics: SKILLS[...]['weeks'] assumes ~10 study
    hours per week and is scaled linearly. Treat them as guidance, not promises.
    """
    info = CAREERS[career]
    required = info["skills"]
    have_set = set(have)
    matched = [s for s in required if s in have_set]
    missing = [s for s in required if s not in have_set]
    match_pct = round(100 * len(matched) / len(required))

    to_learn = _order_with_prereqs(required, have_set)
    scale = 10 / max(1, hours_per_week)
    steps: list[dict] = []
    for skill in to_learn:
        dependents = sorted({d for d in to_learn + required if skill in SKILLS[d]["prereq"]})
        if skill in required:
            why = f"Core skill for a {career}."
        elif dependents:
            why = "Prerequisite for " + ", ".join(dependents) + "."
        else:
            why = "Supports your career goal."
        steps.append({
            "id": f"{career}|learn|{skill}", "type": "learn", "title": f"Learn {skill}",
            "weeks": max(1, math.ceil(SKILLS[skill]["weeks"] * scale)),
            "why": why, "resources": SKILLS[skill]["resources"], "details": [],
        })

    steps.append({
        "id": f"{career}|projects", "type": "projects", "title": "Build portfolio projects",
        "weeks": math.ceil(6 * scale), "why": "Projects prove your skills to recruiters.",
        "resources": [], "details": info["projects"],
    })
    steps.append({
        "id": f"{career}|cert", "type": "cert", "title": "Earn a certificate (optional but helpful)",
        "weeks": math.ceil(3 * scale), "why": "A certificate adds a visible credential to your profile.",
        "resources": [], "details": info["certs"],
    })
    steps.append({
        "id": f"{career}|internship", "type": "internship", "title": "Apply for internships",
        "weeks": 4, "why": "Real experience is the bridge from learning to a job.",
        "resources": [], "details": [INTERNSHIP_TIP.format(career=career)],
    })
    steps.append({
        "id": f"{career}|career", "type": "career", "title": f"Career: {career}",
        "weeks": 0, "why": "Apply for entry-level roles with your projects and internship experience.",
        "resources": [], "details": [],
    })

    path_text = (
        (" + ".join(matched) if matched else "Starting fresh")
        + (" -> gap: " + ", ".join(missing) if missing else " -> no gaps found")
        + " -> projects -> internship -> " + career
    )
    return {
        "career": career, "matched": matched, "missing": missing, "match_pct": match_pct,
        "steps": steps, "learn_count": len(to_learn),
        "total_weeks": sum(s["weeks"] for s in steps), "path_text": path_text,
    }


def offline_summary(roadmap: dict) -> str:
    """A plain-language mentor note that needs no AI key."""
    career = roadmap["career"]
    if not roadmap["missing"]:
        return (f"You already have every core skill tracked for {career}. Focus on portfolio "
                "projects and internship applications - that is what turns skills into offers.")
    nxt = roadmap["steps"][0]
    return (
        f"You match {roadmap['match_pct']}% of the core skills for a {career}. "
        f"Your biggest gaps are: {', '.join(roadmap['missing'])}. "
        f"Start with '{nxt['title']}' - {nxt['why'].lower()} "
        f"At your current study time the full path is roughly {roadmap['total_weeks']} weeks. "
        "Finish one step at a time, and check in daily to keep your streak going."
    )


def offline_mentor_reply(question: str, roadmap: dict) -> str:
    q = question.lower()
    nxt = next((s for s in roadmap["steps"]), None)
    if any(w in q for w in ("next", "start", "begin", "first")) and nxt:
        res = nxt["resources"][0] if nxt["resources"] else "see the roadmap tab"
        return f"Your next step is: {nxt['title']} (~{nxt['weeks']} weeks). Try: {res}."
    if any(w in q for w in ("long", "time", "weeks", "months")):
        return f"Roughly {roadmap['total_weeks']} weeks at your current weekly study hours (a rough estimate)."
    if "project" in q:
        proj = next((s for s in roadmap["steps"] if s["type"] == "projects"), None)
        return "Project ideas:\n- " + "\n- ".join(proj["details"]) if proj else "Open the roadmap tab for ideas."
    if any(w in q for w in ("gap", "missing", "lack")):
        return "Your gaps: " + (", ".join(roadmap["missing"]) or "none tracked") + "."
    return offline_summary(roadmap) + "\n\n(Add an ANTHROPIC_API_KEY to unlock free-form AI mentoring.)"


# --------------------------------------------------------------------------
# Sports track
# --------------------------------------------------------------------------
_TRAIN_DAYS = {3: [0, 2, 4], 4: [0, 1, 3, 5], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5]}
_CYCLE = ["Skill", "Fitness", "Skill", "Match simulation", "Fitness", "Skill"]
_WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def build_training_plan(role: str, level: str, days: int, goal: str = "") -> dict:
    role_info, lv = ROLES[role], LEVELS[level]
    train_idx = _TRAIN_DAYS[max(3, min(6, days))]
    plan_days = []
    n = 0
    for i, weekday in enumerate(_WEEKDAYS):
        if i not in train_idx:
            plan_days.append({
                "day": weekday, "type": "Rest", "minutes": 20,
                "items": ["Active recovery: 20-minute walk and stretching",
                          "Drink water through the day and aim for 7-9 hours of sleep",
                          MENTAL[n % len(MENTAL)]],
            })
            continue
        kind = _CYCLE[n % len(_CYCLE)]
        warm = "Warm-up (10 min): jog, dynamic stretches, shoulder and hip mobility"
        cool = "Cool-down (5 min): slow walk and static stretching"
        if kind == "Skill":
            drills = [role_info["drills"][(n + k) % len(role_info["drills"])] for k in range(3)]
            items = [warm, *drills, MENTAL[n % len(MENTAL)], cool]
        elif kind == "Fitness":
            items = [warm] + [
                f"{name}: {round(base * lv['mult'])} x {lv['sets']} sets" for name, base in FITNESS_BASE
            ] + [cool]
        else:
            items = [warm, role_info["match_sim"],
                     f"Afterwards, write down: {role_info['metrics']}", cool]
        plan_days.append({"day": weekday, "type": kind, "minutes": lv["minutes"], "items": items})
        n += 1

    notes = [
        "This is general training guidance, not medical advice. Work with a coach where you can.",
        "Increase workload gradually - sudden jumps in training are a common cause of injury.",
        "Stop and rest if something hurts (not just feels tired), and see a doctor if pain continues.",
    ]
    if role == "Fast Bowler":
        notes.append("Fast bowlers: keep a log of how many balls you bowl each week and avoid big spikes.")
    if goal:
        notes.insert(0, f"Goal: {goal}. Track your numbers weekly so you can see progress toward it.")
    return {"days": plan_days, "notes": notes}


# --------------------------------------------------------------------------
# Business track
# --------------------------------------------------------------------------
def score_idea(scores: dict[str, int]) -> dict:
    total = sum(scores.values())
    pct = round(100 * total / (5 * len(scores))) if scores else 0
    weakest = [name for name, _ in sorted(scores.items(), key=lambda kv: kv[1])[:2]]
    if pct >= 75:
        verdict = "Strong start. Move on to market validation and test it with real customers."
    elif pct >= 50:
        verdict = "Promising, but has gaps. Strengthen the weakest areas before you build."
    else:
        verdict = "Early stage. Talk to about 10 potential customers to sharpen the idea first."
    return {"total": total, "pct": pct, "weakest": weakest, "verdict": verdict}


def stage_item_id(stage: str, item: str) -> str:
    return f"{stage}|{item}"


def business_progress(done: list[str]) -> dict:
    done_set = set(done)
    total = sum(len(s["checklist"]) for s in STAGES)
    count = sum(1 for s in STAGES for it in s["checklist"] if stage_item_id(s["name"], it) in done_set)
    current = next(
        (s["name"] for s in STAGES
         if not all(stage_item_id(s["name"], it) in done_set for it in s["checklist"])),
        STAGES[-1]["name"],
    )
    return {"done": count, "total": total, "pct": round(100 * count / total), "current": current}


# --------------------------------------------------------------------------
# Motivation / retention (the "students drop out" problem)
# --------------------------------------------------------------------------
def streak(checkins: list[str], today: date | None = None) -> int:
    days = {date.fromisoformat(d) for d in checkins}
    if not days:
        return 0
    today = today or date.today()
    last = max(days)
    if (today - last).days > 1:
        return 0
    count, cur = 1, last
    while cur - timedelta(days=1) in days:
        count += 1
        cur -= timedelta(days=1)
    return count


def nudge(streak_days: int, progress_pct: int, days_since_checkin: int | None) -> str:
    if days_since_checkin is None:
        return "Welcome! Check in once today to start your streak - small daily steps beat long breaks."
    if days_since_checkin >= 3:
        return "It has been a few days. No guilt - pick the smallest step on your roadmap and do 20 minutes today."
    if streak_days >= 7:
        return f"{streak_days}-day streak! Consistency is the real skill here. Keep it going."
    if progress_pct >= 50:
        return "You are past the halfway mark on your roadmap. Finish strong."
    return "Good momentum. Tick off one more step this week."


def profile_context(profile: dict, roadmap: dict | None) -> str:
    """Compact profile summary passed to the AI mentor so replies are personal."""
    lines = [f"Student name: {profile.get('name', 'student')}",
             f"Skills they listed: {profile.get('skills_text') or 'none yet'}"]
    if roadmap:
        lines += [f"Career goal: {roadmap['career']}",
                  f"Match with goal: {roadmap['match_pct']}%",
                  f"Skill gaps: {', '.join(roadmap['missing']) or 'none'}",
                  f"Roadmap order: {' > '.join(s['title'] for s in roadmap['steps'])}",
                  f"Weekly study hours: {profile.get('hours', 10)}"]
    sp = profile.get("sports", {})
    lines.append(f"Sports track: {sp.get('role', '?')} ({sp.get('level', '?')}), goal: {sp.get('goal') or 'not set'}")
    biz = profile.get("biz", {})
    if biz.get("name"):
        lines.append(f"Business idea: {biz['name']} - {biz.get('pitch', '')}")
    return "\n".join(lines)
