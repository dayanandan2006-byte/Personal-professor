"""Optional AI mentor. The app works fully without this (rule-based fallback).

Set ANTHROPIC_API_KEY to enable it. Override the model with SKILLBRIDGE_MODEL.
"""
from __future__ import annotations

import os

MODEL = os.getenv("SKILLBRIDGE_MODEL", "claude-sonnet-5-5")

MENTOR_SYSTEM = """You are Skill Bridge AI, a friendly, practical mentor for students and youth \
in Tier-2 and Tier-3 cities in India who may not have access to paid coaching.

Rules:
- Explain WHAT to learn, WHY it matters, and HOW to start, in simple English.
- Prefer free or low-cost resources. Do not invent specific statistics, salaries, or job numbers.
- Be encouraging and concrete. Give small next steps, not long lectures.
- Keep answers under 200 words unless asked for more.
- For sports advice, give general guidance and remind them to work with a coach and avoid sudden workload spikes.
- For business ideas, push them to talk to real customers before building anything.
- If you are unsure, say so and suggest how they can check.

Student context:
{context}
"""


def available() -> bool:
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def ask(context: str, messages: list[dict], max_tokens: int = 600) -> str:
    """messages: [{'role': 'user'|'assistant', 'content': str}, ...]"""
    import anthropic  # imported lazily so the app runs without the package/key

    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=MENTOR_SYSTEM.format(context=context),
        messages=messages,
    )
    return "".join(block.text for block in resp.content if block.type == "text")
