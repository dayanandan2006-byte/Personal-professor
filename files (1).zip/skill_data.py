"""Static knowledge base for Skill Bridge AI.

Everything the offline (no API key) engine needs lives here, so the team can
extend the platform by editing data instead of code.
Course / certificate names are real programs, but always re-check current
availability and price before recommending them to students.
"""

# --------------------------------------------------------------------------
# EDUCATION TRACK
# --------------------------------------------------------------------------
# weeks = rough weeks to reach working level at ~10 study hours / week.
SKILLS = {
    "Python": {
        "prereq": [], "weeks": 4,
        "resources": ["CS50's Introduction to Programming with Python (free)", "Kaggle Learn: Python"],
    },
    "Git & GitHub": {
        "prereq": [], "weeks": 1,
        "resources": ["GitHub Skills (free interactive courses)", "freeCodeCamp: Git and GitHub for beginners"],
    },
    "SQL": {
        "prereq": [], "weeks": 2,
        "resources": ["Kaggle Learn: Intro to SQL", "SQLBolt (free interactive lessons)"],
    },
    "HTML & CSS": {
        "prereq": [], "weeks": 3,
        "resources": ["freeCodeCamp: Responsive Web Design", "MDN Web Docs: Learn web development"],
    },
    "JavaScript": {
        "prereq": ["HTML & CSS"], "weeks": 5,
        "resources": ["freeCodeCamp: JavaScript Algorithms and Data Structures", "javascript.info"],
    },
    "React": {
        "prereq": ["JavaScript"], "weeks": 4,
        "resources": ["react.dev official tutorial", "Full Stack Open (University of Helsinki)"],
    },
    "Node.js & Express": {
        "prereq": ["JavaScript"], "weeks": 3,
        "resources": ["Full Stack Open (University of Helsinki)", "The Odin Project: NodeJS path"],
    },
    "REST APIs": {
        "prereq": [], "weeks": 2,
        "resources": ["MDN: HTTP overview", "Postman Learning Center"],
    },
    "Databases": {
        "prereq": ["SQL"], "weeks": 3,
        "resources": ["CMU / Stanford open database lectures (YouTube)", "PostgreSQL official tutorial"],
    },
    "Data Structures & Algorithms": {
        "prereq": ["Python"], "weeks": 8,
        "resources": ["NeetCode roadmap (free)", "GeeksforGeeks DSA self-paced notes"],
    },
    "Pandas & NumPy": {
        "prereq": ["Python"], "weeks": 3,
        "resources": ["Kaggle Learn: Pandas", "NumPy official beginner guide"],
    },
    "Statistics": {
        "prereq": [], "weeks": 4,
        "resources": ["Khan Academy: Statistics and probability", "NPTEL statistics courses"],
    },
    "Data Visualization": {
        "prereq": ["Pandas & NumPy"], "weeks": 2,
        "resources": ["Kaggle Learn: Data Visualization", "Matplotlib / Seaborn official tutorials"],
    },
    "Machine Learning": {
        "prereq": ["Python", "Statistics", "Pandas & NumPy"], "weeks": 6,
        "resources": ["Andrew Ng: Machine Learning Specialization (Coursera, audit free)", "Kaggle Learn: Intro to Machine Learning"],
    },
    "Deep Learning": {
        "prereq": ["Machine Learning"], "weeks": 6,
        "resources": ["fast.ai: Practical Deep Learning for Coders", "Kaggle Learn: Intro to Deep Learning"],
    },
    "NLP & LLMs": {
        "prereq": ["Deep Learning"], "weeks": 4,
        "resources": ["Hugging Face LLM / NLP course (free)", "Kaggle Learn: Natural Language Processing"],
    },
    "Linux & Command Line": {
        "prereq": [], "weeks": 2,
        "resources": ["Linux Journey (free)", "The Missing Semester of Your CS Education (MIT)"],
    },
    "Docker": {
        "prereq": ["Linux & Command Line"], "weeks": 2,
        "resources": ["Docker official Get Started guide", "freeCodeCamp: Docker for beginners"],
    },
    "Cloud Basics": {
        "prereq": ["Linux & Command Line"], "weeks": 4,
        "resources": ["AWS Cloud Practitioner Essentials (AWS Skill Builder)", "Microsoft Learn: Azure Fundamentals"],
    },
    "CI/CD": {
        "prereq": ["Git & GitHub", "Docker"], "weeks": 2,
        "resources": ["GitHub Actions official docs", "freeCodeCamp: CI/CD course"],
    },
}

CAREERS = {
    "Data Analyst": {
        "skills": ["SQL", "Python", "Pandas & NumPy", "Statistics", "Data Visualization"],
        "projects": [
            "Clean and analyse a public dataset (e.g. a state open-data portal) and publish the findings",
            "Build a sales or expenses dashboard with charts and a written summary",
            "Write a SQL case study answering 10 business questions on a sample database",
        ],
        "certs": ["Google Data Analytics Certificate (Coursera)", "HackerRank SQL certificate"],
    },
    "Data Scientist": {
        "skills": ["Python", "SQL", "Statistics", "Pandas & NumPy", "Data Visualization", "Machine Learning"],
        "projects": [
            "Predict house prices or crop yield from a public dataset and explain the key features",
            "Enter a beginner Kaggle competition and document your approach",
            "Build a small end-to-end ML app (data -> model -> simple web demo)",
        ],
        "certs": ["IBM Data Science Professional Certificate (Coursera)", "NPTEL: Introduction to Machine Learning"],
    },
    "AI/ML Engineer": {
        "skills": ["Python", "Data Structures & Algorithms", "Machine Learning", "Deep Learning",
                   "NLP & LLMs", "Git & GitHub", "Docker"],
        "projects": [
            "Fine-tune or evaluate a small pretrained model on a local-language dataset",
            "Build a retrieval-based Q&A bot over a set of documents",
            "Package an ML model as an API and run it in a Docker container",
        ],
        "certs": ["DeepLearning.AI Machine Learning Specialization (Coursera)", "NPTEL: Deep Learning"],
    },
    "Full-Stack Developer": {
        "skills": ["HTML & CSS", "JavaScript", "React", "Node.js & Express", "Databases", "REST APIs", "Git & GitHub"],
        "projects": [
            "Build and deploy a personal portfolio site",
            "Build a CRUD app (e.g. a student attendance or inventory tracker) with login",
            "Build a small full-stack project that solves a real problem in your town or college",
        ],
        "certs": ["freeCodeCamp Responsive Web Design and JavaScript certifications", "Full Stack Open course completion"],
    },
    "Backend Developer": {
        "skills": ["Python", "Data Structures & Algorithms", "SQL", "Databases", "REST APIs", "Git & GitHub", "Docker"],
        "projects": [
            "Build a REST API with authentication and a database",
            "Build a URL shortener or a rate-limited API and write tests for it",
            "Containerise your API with Docker and deploy it on a free tier",
        ],
        "certs": ["freeCodeCamp Back End Development and APIs certification", "HackerRank SQL certificate"],
    },
    "Cloud & DevOps Engineer": {
        "skills": ["Linux & Command Line", "Git & GitHub", "Python", "Docker", "Cloud Basics", "CI/CD"],
        "projects": [
            "Deploy a static site and an API on a cloud free tier",
            "Set up a CI/CD pipeline that tests and deploys a sample app on every push",
            "Write a shell or Python script that automates a repetitive server task",
        ],
        "certs": ["AWS Certified Cloud Practitioner", "Microsoft Azure Fundamentals (AZ-900)"],
    },
}

INTERNSHIP_TIP = (
    "Search '{career}' on Internshala, LinkedIn and company careers pages. "
    "Keep a public GitHub portfolio with 2-3 finished projects, and write a short README for each "
    "explaining the problem, your approach and the result."
)

# Words students commonly type -> canonical skill name.
ALIASES = {
    "py": "Python", "python3": "Python", "python programming": "Python",
    "js": "JavaScript", "javascript": "JavaScript", "node": "Node.js & Express",
    "nodejs": "Node.js & Express", "node.js": "Node.js & Express", "express": "Node.js & Express",
    "ml": "Machine Learning", "machine learning": "Machine Learning",
    "dl": "Deep Learning", "nlp": "NLP & LLMs", "llm": "NLP & LLMs", "llms": "NLP & LLMs",
    "html": "HTML & CSS", "css": "HTML & CSS", "html/css": "HTML & CSS", "html5": "HTML & CSS",
    "git": "Git & GitHub", "github": "Git & GitHub",
    "pandas": "Pandas & NumPy", "numpy": "Pandas & NumPy",
    "dsa": "Data Structures & Algorithms", "data structures": "Data Structures & Algorithms",
    "algorithms": "Data Structures & Algorithms",
    "linux": "Linux & Command Line", "bash": "Linux & Command Line", "shell": "Linux & Command Line",
    "aws": "Cloud Basics", "azure": "Cloud Basics", "gcp": "Cloud Basics", "cloud": "Cloud Basics",
    "api": "REST APIs", "apis": "REST APIs", "rest": "REST APIs", "rest api": "REST APIs",
    "stats": "Statistics", "probability": "Statistics",
    "matplotlib": "Data Visualization", "tableau": "Data Visualization", "power bi": "Data Visualization",
    "powerbi": "Data Visualization", "visualization": "Data Visualization", "visualisation": "Data Visualization",
    "mysql": "SQL", "postgres": "SQL", "postgresql": "SQL", "sqlite": "SQL",
    "mongodb": "Databases", "database": "Databases", "dbms": "Databases",
    "reactjs": "React", "react.js": "React", "cicd": "CI/CD", "ci cd": "CI/CD",
}

# --------------------------------------------------------------------------
# SPORTS TRACK (cricket)
# --------------------------------------------------------------------------
ROLES = {
    "Batter": {
        "drills": [
            "Shadow batting: front-foot and back-foot defence, 3 x 10 reps",
            "Net practice with a tennis or cork ball: play straight, 5 sets of 6 balls",
            "Target hitting: mark gaps with cones and aim shots into them",
            "Running between the wickets: 6 x 20 m with turns, then 2s and 3s",
        ],
        "match_sim": "Net match: 6 overs, a set target and a fall-of-wicket rule. Rebuild after each 'wicket'.",
        "metrics": "balls faced and how many you controlled cleanly",
    },
    "Fast Bowler": {
        "drills": [
            "Run-up rhythm: 6 x 8-step smooth run-ups at 60% effort, no ball",
            "Line and length: bowl at a target spot, 4 sets of 6 balls",
            "Bowling-arm and shoulder mobility circuits",
            "Yorker and slower-ball practice at a marked target",
        ],
        "match_sim": "Bowl a 4-over spell with a field set; track balls landed on your target length.",
        "metrics": "balls on target length out of balls bowled",
    },
    "Spin Bowler": {
        "drills": [
            "Grip and revolutions: 5 sets of 6 balls focusing on spin, not pace",
            "Land the ball on a handkerchief-sized target, 4 sets of 6",
            "Flight variation: bowl the same line at three different heights",
            "Wrist and finger strengthening with a soft ball or putty",
        ],
        "match_sim": "Bowl a 4-over spell against a batter told to attack; try a variation each over.",
        "metrics": "balls on target out of balls bowled",
    },
    "Wicketkeeper": {
        "drills": [
            "Stance and glove position, 10 minutes of low-to-ground work",
            "Reaction catches: partner throws from 5 m with random angles",
            "Footwork to stumps: collect wide throws and break the stumps",
            "Standing-up practice to a spinner (or a partner feeding rolled balls)",
        ],
        "match_sim": "Keep through a 6-over net match, calling every appeal and tracking dropped chances.",
        "metrics": "catches taken out of chances",
    },
    "All-rounder": {
        "drills": [
            "Batting: front/back-foot defence shadow drills, 3 x 10",
            "Bowling: target spot practice, 4 sets of 6 balls",
            "Fielding: catching under pressure and flat throws to the stumps",
            "Running between the wickets: 6 x 20 m with turns",
        ],
        "match_sim": "Play a mini-match: bat 3 overs, bowl 3 overs, field the rest, and review each part.",
        "metrics": "balls controlled, balls on target and catches taken",
    },
}

# base reps for a beginner; scaled by level
FITNESS_BASE = [
    ("Squats", 12), ("Push-ups", 8), ("Lunges (each leg)", 8),
    ("Plank (seconds)", 30), ("Skipping (minutes)", 4), ("Shuttle runs 10 m (rounds)", 4),
]
LEVELS = {
    "Beginner": {"mult": 1.0, "sets": 2, "minutes": 45},
    "Intermediate": {"mult": 1.5, "sets": 3, "minutes": 60},
    "Advanced": {"mult": 2.0, "sets": 4, "minutes": 75},
}
MENTAL = [
    "Box breathing: inhale 4s, hold 4s, exhale 4s, hold 4s, for 5 rounds",
    "Visualise 5 perfect balls or shots in your role before you start",
    "Build a pre-ball routine: one breath, one trigger word, one target",
    "Journal for 5 minutes: one thing that went well and one thing to fix",
]

# --------------------------------------------------------------------------
# BUSINESS TRACK
# --------------------------------------------------------------------------
STAGES = [
    {
        "name": "Idea",
        "goal": "State the problem and who has it, clearly",
        "checklist": [
            "Write the problem in one sentence",
            "Name your target customer as specifically as you can",
            "List 3 ways people solve this problem today",
            "Write a one-line value proposition",
        ],
    },
    {
        "name": "Market Validation",
        "goal": "Check that real people care before you build",
        "checklist": [
            "Talk to at least 10 potential customers",
            "Record the top 3 pains you heard in their own words",
            "Estimate how many such customers exist near you",
            "Ask at least 3 people if they would pay, and how much",
        ],
    },
    {
        "name": "MVP",
        "goal": "Build the smallest thing that solves the core problem",
        "checklist": [
            "List the single core feature your MVP needs",
            "Choose a no-code, spreadsheet or simple-code way to build it",
            "Build it in 4-6 weeks or less",
            "Get it into the hands of 5 real users",
        ],
    },
    {
        "name": "Feedback",
        "goal": "Learn what users actually do and say",
        "checklist": [
            "Observe at least 5 users trying the MVP",
            "Collect feedback with a short form or call",
            "Track one number that shows value (e.g. repeat use)",
            "Write down what surprised you",
        ],
    },
    {
        "name": "Improvement",
        "goal": "Fix the biggest problems and repeat",
        "checklist": [
            "Rank the feedback by how many users mentioned it",
            "Fix the top 2 issues",
            "Re-test with the same users",
            "Decide: keep going, change direction, or stop",
        ],
    },
    {
        "name": "Growth",
        "goal": "Find a repeatable way to reach more customers",
        "checklist": [
            "Find the one channel that works best for you",
            "Set a simple price and test it",
            "Track cost to acquire a customer vs. what they pay",
            "Write a one-page plan for the next 3 months",
        ],
    },
]

SCORE_CRITERIA = [
    ("Problem urgency", "How painful is this problem for your customer today?"),
    ("Market size", "How many people could realistically need this?"),
    ("Differentiation", "How different is your idea from what exists?"),
    ("Buildability", "Can you build a first version in 4-6 weeks?"),
    ("Willingness to pay", "Would customers pay (or clearly benefit) for it?"),
    ("Founder commitment", "How committed are you to working on this for a year?"),
]
