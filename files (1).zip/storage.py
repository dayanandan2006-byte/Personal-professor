"""Tiny JSON-file persistence so progress survives page refreshes."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

from skill_data import SCORE_CRITERIA

DATA_DIR = Path(__file__).parent / "data"

DEFAULT_PROFILE = {
    "name": "",
    "skills_text": "Python, SQL",
    "career": "Data Scientist",
    "hours": 10,
    "done": [],          # completed roadmap step ids
    "checkins": [],      # ISO dates
    "sports": {"role": "Batter", "level": "Beginner", "days": 4, "goal": "", "logs": []},
    "biz": {
        "name": "", "pitch": "",
        "scores": {name: 3 for name, _ in SCORE_CRITERIA},
        "done": [],      # completed checklist item ids
    },
}


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-") or "guest"


def _merge(default: dict, loaded: dict) -> dict:
    """Fill any missing keys from defaults so older save files keep working."""
    out = copy.deepcopy(default)
    for key, value in loaded.items():
        if isinstance(out.get(key), dict) and isinstance(value, dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def load_profile(name: str) -> dict:
    path = DATA_DIR / f"{slug(name)}.json"
    profile = copy.deepcopy(DEFAULT_PROFILE)
    if path.exists():
        try:
            profile = _merge(DEFAULT_PROFILE, json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            pass  # corrupted file -> start fresh rather than crash the demo
    profile["name"] = name
    return profile


def save_profile(profile: dict) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    path = DATA_DIR / f"{slug(profile['name'])}.json"
    path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
